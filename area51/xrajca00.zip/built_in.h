//Implementace interpretu imperativního jazyka IFJ12.
//xbucht18, Buchta David

#ifndef BUILT_IN_H
#define BUILT_IN_H

//built in fundtions
void bi_input(char **); // input()
int bi_numeric(char *, double *);

#endif // BUILT_IN_H
