//Implementace interpretu imperativního jazyka IFJ12.
// xpokor57, Pokorny Oto
// xsidlo02, Sidlo Boleslav

#include <stdio.h>

#include "global.h"
#include "parser.h"

FILE *pSource_File;

int main(int argc, char **argv)
{
	int result;

	if(argc!=2)
	{
		printf("Spatne parametry\n");
		return 1;
	}
	if((pSource_File=fopen(argv[1], "r"))==NULL)
	{
		printf("Soubor se nepodarilo otevrit.\n");
		return 1;
	}

	result=parser();
	if(result!=PROG_OK)
		print_error(result);

	return result;
}
